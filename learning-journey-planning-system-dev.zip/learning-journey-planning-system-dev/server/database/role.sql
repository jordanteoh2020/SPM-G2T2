DELETE FROM `role`;

INSERT INTO `role` (`Role_ID`, `Role_Name`) VALUES ('1', 'Admin'), ('2', 'User'), ('3', 'Manager'), ('4', 'Trainer');