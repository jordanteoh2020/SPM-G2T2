export type Skill = {
  skill_id: number;
  skill_name: string;
  skill_desc: string;
  skill_status: string;
};
