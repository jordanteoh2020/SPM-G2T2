export type Role = {
  position_id: number;
  position_name: string;
  position_desc: string;
  position_dept: string;
  position_res: string;
  position_status: string;
};
