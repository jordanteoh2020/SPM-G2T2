export type Course = {
  course_id: string;
  course_name: string;
  course_desc: string;
  course_type: string;
  course_category: string;
  course_status: string;
};
